import React, { Component } from 'react';

class Confirm extends Component {
    constructor(props) {
        super(props)

        this.state = {

        }
    }

    render() {
        return (
            <div className="fixed-bottom">
                <h1>Your booking has been confirmed.</h1>
            </div>
        )
    }
}

export default Confirm;