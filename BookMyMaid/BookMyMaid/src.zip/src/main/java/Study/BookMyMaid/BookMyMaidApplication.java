package Study.BookMyMaid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyMaidApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyMaidApplication.class, args);
	}

}
